import os, asyncio, json, time
from broadcaster import broadcast
from risk import position_size_by_risk

CONF_THRESH = float(os.getenv('CONF_THRESH', '0.75'))
LEVERAGE = int(os.getenv('LEVERAGE', '5'))
RISK_PCT = float(os.getenv('RISK_PCT', '0.02'))  # default stop 2% for executions

async def evaluate_and_execute(agg, signals, symbol, exchange, db, logger):
    confidence = float(agg.get('score', 0.0))
    side = agg.get('side', 'none')
    conf_pct = round(confidence * 100, 1)
    reasons = ', '.join([f"{s['strategy']}:{s.get('score',0):.2f}" for s in signals])
    if confidence < CONF_THRESH or side not in ('buy','sell'):
        msg = f"🚫 Trade skipped (Alignment {conf_pct}%) — Confidence below 75%"
        await broadcast(f"🔎 {symbol} confluence: {confidence:.3f} | side={side} | strategies={len(signals)}\n{msg}\nBreakdown: {reasons}")
        logger.log_attempt({'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'executed': False, 'reason': 'low_confidence', 'breakdown': signals})
        return {'executed': False, 'reason': 'low_confidence'}

    # fetch entry price
    try:
        df = exchange.fetch_ohlcv_df(symbol, timeframe=os.getenv('TIMEFRAMES','1m').split(',')[0], limit=10)
        entry = float(df['close'].iloc[-1])
    except Exception as e:
        await broadcast(f"❗ Failed to fetch latest price for {symbol}: {e}")
        logger.log_attempt({'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'executed': False, 'reason': 'fetch_price_failed', 'breakdown': signals})
        return {'executed': False, 'reason': 'fetch_price_failed'}

    stop_pcts = [s.get('stop_pct') for s in signals if s.get('stop_pct') is not None]
    take_mults = [s.get('take_multiplier') for s in signals if s.get('take_multiplier') is not None]
    stop_pct = float(sum(stop_pcts)/len(stop_pcts)) if stop_pcts else 0.02
    take_mult = float(sum(take_mults)/len(take_mults)) if take_mults else 1.5

    # enforce user's requested 50% TP (implied) but keep strategy guidance
    if side == 'buy':
        implied_take = entry * 1.5
        take_price = max(implied_take, entry + (entry - entry*(1-stop_pct))*take_mult)
        stop_price = entry * (1 - stop_pct)
    else:
        implied_take = entry * 0.5
        take_price = min(implied_take, entry - (entry*(1-stop_pct) - entry)*take_mult)
        stop_price = entry * (1 + stop_pct)

    equity = exchange.get_balance()
    qty, notional = position_size_by_risk(equity, RISK_PCT, entry, stop_price)
    if qty <= 0:
        await broadcast(f"❗ Position size calculated as zero or invalid for {symbol}. Skipping.")
        logger.log_attempt({'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'executed': False, 'reason': 'invalid_qty', 'breakdown': signals})
        return {'executed': False, 'reason': 'invalid_qty'}

    try:
        await exchange.set_leverage(symbol, LEVERAGE)
    except Exception:
        pass

    try:
        order_res = await exchange.create_order(symbol, side, qty, price=None, params={})
    except Exception as e:
        await broadcast(f"❗ Order create failed for {symbol}: {e}")
        logger.log_attempt({'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'executed': False, 'reason': 'order_failed', 'breakdown': signals})
        return {'executed': False, 'reason': 'order_failed'}

    trade_entry = {'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'entry': entry, 'stop': stop_price, 'take': take_price, 'qty': qty, 'notional': notional, 'order_res': order_res}
    try:
        db.log_trade(trade_entry)
    except Exception:
        pass
    logger.log_attempt({'ts': time.time(), 'symbol': symbol, 'side': side, 'confidence': confidence, 'executed': True, 'reason': 'executed', 'breakdown': signals, 'entry': entry, 'stop': stop_price, 'take': take_price, 'qty': qty})

    await broadcast(f"✅ Trade Executed (Alignment {round(confidence*100,1)}%) — {symbol} {side.upper()}\nEntry={entry:.6f} Stop={stop_price:.6f} Take={take_price:.6f} Qty={qty:.6f} (Leverage={LEVERAGE}x)")
    return {'executed': True, 'entry': entry, 'stop': stop_price, 'take': take_price, 'qty': qty, 'order_res': order_res}
