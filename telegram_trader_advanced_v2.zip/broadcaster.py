import os
from telegram import Bot
TG_TOKEN=os.getenv('TG_TOKEN'); CHAT_ID=int(os.getenv('ADMIN_CHAT_ID','0'))
bot=Bot(token=TG_TOKEN)
async def broadcast(text):
    try:
        await bot.send_message(CHAT_ID, text)
    except Exception:
        try: bot.send_message(CHAT_ID, text)
        except: print('broadcast failed', text)
