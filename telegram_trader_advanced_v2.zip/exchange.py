import ccxt.async_support as ccxt, os, asyncio, logging, pandas as pd
log=logging.getLogger('exchange')
class ExchangeClient:
    def __init__(self, provider='binance', api_key=None, api_secret=None, demo=True):
        self.provider=provider; self.demo=demo; self.api_key=api_key or os.getenv('API_KEY'); self.api_secret=api_secret or os.getenv('API_SECRET')
        self._init_exchange(); self.loop=asyncio.get_event_loop()
    def _init_exchange(self):
        excls=getattr(ccxt, self.provider)
        self.exchange=excls({'apiKey':self.api_key,'secret':self.api_secret,'enableRateLimit':True})
    async def set_leverage(self, symbol, leverage):
        if self.demo:
            log.info(f'[DEMO] set_leverage {symbol} x{leverage}'); return {'status':'demo'}
        try: return await self.exchange.set_leverage(leverage, symbol)
        except Exception as e: log.exception('set_leverage'); raise
    async def create_order(self, symbol, side, amount, price=None, params={}):
        side=side.lower()
        if self.demo:
            log.info(f'[DEMO] create_order {symbol} {side} {amount} price={price}'); return {'status':'demo','symbol':symbol,'side':side,'amount':amount,'price':price}
        order_type='market' if price is None else 'limit'
        try:
            res=await self.exchange.create_order(symbol, order_type, side, amount, price, params)
            return res
        except Exception as e:
            log.exception('create_order'); raise
    def fetch_ohlcv_df(self, symbol, timeframe='1m', limit=500):
        loop=asyncio.get_event_loop()
        bars=loop.run_until_complete(self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit))
        df=pd.DataFrame(bars, columns=['ts','open','high','low','close','volume'])
        df['ts']=pd.to_datetime(df['ts'], unit='ms'); df.set_index('ts', inplace=True)
        return df
    def get_balance(self):
        if self.demo: return 10000.0
        loop=asyncio.get_event_loop(); bal=loop.run_until_complete(self.exchange.fetch_balance())
        total=bal.get('total',{}); return float(total.get('USDT',0) or total.get('USD',0) or 0)
