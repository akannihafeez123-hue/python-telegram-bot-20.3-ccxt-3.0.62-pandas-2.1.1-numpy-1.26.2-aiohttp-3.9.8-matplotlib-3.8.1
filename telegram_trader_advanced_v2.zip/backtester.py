import pandas as pd, numpy as np, json
from confluence import aggregate_signals
from risk import position_size_by_risk
import importlib
STRATEGY_MODULES = [
    'strategies.fibonacci_vortex',
    'strategies.quantum_entanglement',
    'strategies.darkpool_institutional',
    'strategies.gann_square',
    'strategies.elliott_neural',
    'strategies.cosmic_movement',
    'strategies.exclusive'
]

def load_csv(path):
    df=pd.read_csv(path, parse_dates=['ts'])
    df.set_index('ts', inplace=True)
    return df

def simulate(symbol_df, timeframes, conf_thresh=0.75, risk_pct=0.01, leverage=5, initial_equity=10000):
    equity=initial_equity; equity_curve=[equity]; trades=[]
    # For each day/row use the latest bar as decision point; simple single-tf backtest using provided dataframe slices
    for i in range(60, len(symbol_df)):
        # build a mini-df up to i for strategies
        df_window = symbol_df.iloc[:i].copy()
        signals=[]
        for mod in STRATEGY_MODULES:
            try:
                module=importlib.import_module(mod)
                # feed same df as all tfs for simplicity
                r = module.score(df_window, 'backtest', 'SYMBOL')
                if r and r.get('score',0)>0:
                    signals.append(r)
            except Exception as e:
                continue
        agg = aggregate_signals(signals)
        if agg['score'] >= conf_thresh and agg['side'] in ('buy','sell'):
            entry = float(df_window['close'].iloc[-1])
            stop = entry*0.98 if agg['side']=='buy' else entry*1.02
            qty, notional = position_size_by_risk(equity, risk_pct, entry, stop)
            # simulate simple next-bar outcome: use next bar close as exit
            next_close = float(symbol_df['close'].iloc[i])
            pnl_per_unit = (next_close - entry) if agg['side']=='buy' else (entry - next_close)
            pnl = pnl_per_unit * qty * leverage
            equity += pnl
            trades.append({'i':i,'side':agg['side'],'entry':entry,'exit':next_close,'pnl':pnl,'score':agg['score']})
        equity_curve.append(equity)
    # metrics
    returns = np.array(equity_curve)/initial_equity - 1
    max_dd = (np.maximum.accumulate(equity_curve) - equity_curve).max()
    wins = [t for t in trades if t['pnl']>0]
    win_rate = len(wins)/len(trades) if trades else 0
    return {'trades':trades,'final_equity':equity,'win_rate':win_rate,'max_drawdown':max_dd,'equity_curve':equity_curve}
