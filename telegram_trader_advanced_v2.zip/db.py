import sqlite3, json
class DB:
    def __init__(self,path='trader.db'):
        self.conn=sqlite3.connect(path,check_same_thread=False)
        self._init()
    def _init(self):
        c=self.conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS config (k TEXT PRIMARY KEY, v TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY, ts DATETIME DEFAULT CURRENT_TIMESTAMP, data TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS equity (ts DATETIME DEFAULT CURRENT_TIMESTAMP, equity REAL)')
        self.conn.commit()
    def set_config(self,k,v): self.conn.execute('INSERT OR REPLACE INTO config (k,v) VALUES (?,?)',(k,str(v))); self.conn.commit()
    def get_config(self,k):
        r=self.conn.execute('SELECT v FROM config WHERE k=?',(k,)).fetchone()
        return r[0] if r else None
    def log_trade(self,d): self.conn.execute('INSERT INTO trades (data) VALUES (?)',(json.dumps(d),)); self.conn.commit()
    def snapshot_equity(self,e): self.conn.execute('INSERT INTO equity (equity) VALUES (?)',(e,)); self.conn.commit()
    def get_last_equity(self):
        r=self.conn.execute('SELECT equity FROM equity ORDER BY ts DESC LIMIT 1').fetchone()
        return float(r[0]) if r else 0.0
