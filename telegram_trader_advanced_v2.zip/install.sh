#!/bin/bash
set -e
echo "Creating virtualenv in .venv ..."
python3 -m venv .venv
source .venv/bin/activate
echo "Upgrading pip..."
pip install --upgrade pip
echo "Installing requirements..."
pip install -r requirements.txt
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo ""
  echo ".env created from .env.example. Edit .env and add your TG_TOKEN, ADMIN_CHAT_ID, and exchange API keys."
else
  echo ".env already exists. Please ensure it contains your secrets and correct settings."
fi
echo ""
echo "Setup complete. Activate venv with: source .venv/bin/activate"
echo "Run bot with: python main.py"
