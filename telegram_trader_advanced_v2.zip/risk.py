def position_size_by_risk(account_equity, risk_pct, entry_price, stop_price, contract_value_per_unit=1.0):
    risk_amount=account_equity*risk_pct
    stop_distance=abs(entry_price-stop_price)
    if stop_distance<=0: raise ValueError('stop distance must be >0')
    qty=risk_amount/(stop_distance*contract_value_per_unit)
    notional=qty*entry_price
    return qty, notional
