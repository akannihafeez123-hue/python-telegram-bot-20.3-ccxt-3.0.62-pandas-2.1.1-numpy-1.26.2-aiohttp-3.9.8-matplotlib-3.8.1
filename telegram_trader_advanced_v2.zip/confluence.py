import numpy as np
def aggregate_signals(signals,min_strategies=3,min_timeframes=2):
    if not signals: return {'score':0.0,'side':'none','breakdown':{}}
    strat_scores={}; tfs=set(); sides=[]
    for s in signals:
        strat_scores.setdefault(s['strategy'], []).append(s['score'])
        tfs.add(s['tf']); sides.append(s.get('side','none'))
    best={k:max(v) for k,v in strat_scores.items()}
    avg=float(np.mean(list(best.values()))) if best else 0.0
    side='buy' if sides.count('buy')>sides.count('sell') else ('sell' if sides.count('sell')>sides.count('buy') else 'none')
    if len(best)<min_strategies: avg*=0.6
    if len(tfs)<min_timeframes: avg*=0.7
    return {'score':round(avg,4),'side':side,'num_strategies':len(best),'timeframes':list(tfs),'best_per_strat':best}
