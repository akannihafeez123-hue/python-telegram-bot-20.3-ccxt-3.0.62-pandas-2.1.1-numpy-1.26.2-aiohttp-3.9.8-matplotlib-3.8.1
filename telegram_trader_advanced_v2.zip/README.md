# Telegram Trader Framework

This package contains a demo autonomous Telegram trading bot framework:
- Multi-strategy modular detectors
- Confluence engine
- Backtester (CSV OHLCV)
- Installer script to create venv and install dependencies

**Security:** Do NOT place API keys in files. Use environment variables (.env). Fill `.env` from `.env.example`.

See `install.sh` to set up a Python virtual environment and install dependencies.

