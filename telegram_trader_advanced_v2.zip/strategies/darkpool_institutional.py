def score(df,tf,symbol):
    # volume spike + candle imbalance heuristic for stealth institutional buying
    if len(df)<40: return {'strategy':'darkpool_institutional','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    last=df.iloc[-1]; prev_mean = df['volume'].iloc[-20:-1].mean()
    vol_spike = last['volume'] > prev_mean * 3
    body = abs(last['close'] - last['open'])
    side = 'buy' if last['close'] > last['open'] else 'sell'
    score = 0.7 if vol_spike and (body/last['open']>0.004) else 0.0
    return {'strategy':'darkpool_institutional','tf':tf,'symbol':symbol,'score':score,'side':side,'meta':{'vol_spike':bool(vol_spike),'body':float(body)}}
