import pandas_ta as ta
def score(df,tf,symbol):
    # RSI + EMA + price near recent fib levels (approx)
    if len(df)<55: return {'strategy':'fibonacci_vortex','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    close=df['close']; rsi=ta.rsi(close, length=14).iloc[-1]
    ema21=ta.ema(close, length=21).iloc[-1]
    last=close.iloc[-1]; high=close[-50:].max(); low=close[-50:].min()
    # approximate fib distance
    fib38 = high - (high-low)*0.382
    near_fib = abs(last - fib38) / last < 0.01
    score=0.0; side='none'
    if rsi < 35 and last>ema21:
        score += 0.4; side='buy'
    if rsi > 65 and last<ema21:
        score += 0.4; side='sell'
    if near_fib: score += 0.2
    return {'strategy':'fibonacci_vortex','tf':tf,'symbol':symbol,'score':min(score,1.0),'side':side,'meta':{'rsi':float(rsi),'near_fib':bool(near_fib)}}
