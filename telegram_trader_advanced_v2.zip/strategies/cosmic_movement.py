import pandas as pd
def score(df,tf,symbol):
    # playful lunar-cycle proxy: use day-of-month phase influence (not scientific)
    if len(df)<60: return {'strategy':'cosmic_movement','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    last_ts = df.index[-1]
    day = last_ts.day
    # simple heuristic: certain days favor momentum
    score = 0.25 if day%2==0 else 0.0
    # direction by recent slope
    slope = df['close'].iloc[-3:].diff().mean()
    side = 'buy' if slope>0 else 'sell'
    return {'strategy':'cosmic_movement','tf':tf,'symbol':symbol,'score':score,'side':side,'meta':{'day':int(day)}}
