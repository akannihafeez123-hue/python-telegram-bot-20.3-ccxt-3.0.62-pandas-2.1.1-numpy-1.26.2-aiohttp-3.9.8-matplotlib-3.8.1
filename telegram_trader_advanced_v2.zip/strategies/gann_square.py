import numpy as np
def score(df,tf,symbol):
    # naive time-cycle proxy: look for repeating peaks every N bars (small heuristic)
    if len(df)<200: return {'strategy':'gann_square','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    close=df['close']
    window=20
    recent = close.iloc[-(window*6):]
    # check simple autocorrelation peak
    ac = np.corrcoef(recent.values, np.roll(recent.values, window))[0,1]
    score=0.5 if ac>0.6 else 0.0
    # direction by slope short-term
    slope = close.iloc[-5:].diff().mean()
    side = 'buy' if slope>0 else 'sell'
    return {'strategy':'gann_square','tf':tf,'symbol':symbol,'score':score,'side':side,'meta':{'ac':float(ac)}}
