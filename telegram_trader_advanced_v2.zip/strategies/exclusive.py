def score(df,tf,symbol):
    # master confluence: combine simple features quickly (this boosts when others align)
    # For speed this module looks for strong candle + volume agreement
    if len(df)<30: return {'strategy':'exclusive','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    last=df.iloc[-1]
    prev_vol = df['volume'].iloc[-5:-1].mean()
    vol_boost = last['volume'] > prev_vol*2
    body_ratio = abs(last['close'] - last['open']) / last['open']
    score = 0.0
    side = 'none'
    if vol_boost and body_ratio>0.008:
        score = 0.8
        side = 'buy' if last['close']>last['open'] else 'sell'
    return {'strategy':'exclusive','tf':tf,'symbol':symbol,'score':score,'side':side,'meta':{'vol_boost':bool(vol_boost),'body_ratio':float(body_ratio)}}
