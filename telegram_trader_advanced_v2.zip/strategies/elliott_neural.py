import pandas_ta as ta
def score(df,tf,symbol):
    # lightweight wave-like detection: count recent impulse vs corrective swings
    if len(df)<80: return {'strategy':'elliott_neural','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    close = df['close']
    diffs = close.diff().fillna(0)
    impulses = (diffs>0).astype(int).rolling(5).sum().iloc[-1]
    corrections = (diffs<0).astype(int).rolling(5).sum().iloc[-1]
    score=0.0; side='none'
    if impulses >= 4:
        score = 0.6; side='buy'
    elif corrections >=4:
        score = 0.6; side='sell'
    # boost if RSI agrees
    rsi = ta.rsi(close,14).iloc[-1]
    if (side=='buy' and rsi<60) or (side=='sell' and rsi>40):
        score += 0.15
    return {'strategy':'elliott_neural','tf':tf,'symbol':symbol,'score':min(score,1.0),'side':side,'meta':{'impulses':int(impulses),'rsi':float(rsi)}}
