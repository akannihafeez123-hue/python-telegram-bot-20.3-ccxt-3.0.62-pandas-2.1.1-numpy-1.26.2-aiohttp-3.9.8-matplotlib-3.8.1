import pandas_ta as ta
def score(df,tf,symbol):
    # MACD + EMA crossover + volatility filter – treated as 'quantum' probabilistic signal
    if len(df)<50: return {'strategy':'quantum_entanglement','tf':tf,'symbol':symbol,'score':0.0,'side':'none','meta':{}}
    close=df['close']
    ema8=ta.ema(close,8); ema21=ta.ema(close,21)
    macd=ta.macd(close)
    hist = macd['MACDh_12_26_9'].iloc[-1] if 'MACDh_12_26_9' in macd else 0
    vol = df['volume'].iloc[-1]; avgvol = df['volume'].iloc[-20:-1].mean()
    score=0.0; side='none'
    if ema8.iloc[-1] > ema21.iloc[-1] and ema8.iloc[-2] <= ema21.iloc[-2]:
        score += 0.35; side='buy'
    if ema8.iloc[-1] < ema21.iloc[-1] and ema8.iloc[-2] >= ema21.iloc[-2]:
        score += 0.35; side='sell'
    if hist>0: score += 0.15
    if vol > (avgvol*1.5): score += 0.15
    return {'strategy':'quantum_entanglement','tf':tf,'symbol':symbol,'score':min(score,1.0),'side':side,'meta':{'macd_hist':float(hist),'vol':float(vol)}}
