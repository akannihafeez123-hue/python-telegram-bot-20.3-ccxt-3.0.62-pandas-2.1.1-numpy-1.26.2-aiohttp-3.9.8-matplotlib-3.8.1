import os, asyncio, importlib, logging
from dotenv import load_dotenv
from db import DB
from exchange import ExchangeClient
from confluence import aggregate_signals
from execution import evaluate_and_execute
from summary_logger import SummaryLogger

from risk import position_size_by_risk
from broadcaster import broadcast

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("main")

DEMO_MODE = os.getenv("DEMO_MODE","true").lower()=="true"
SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS","BTC/USDT").split(",")]
TIMEFRAMES = [t.strip() for t in os.getenv("TIMEFRAMES","1m,5m,1h").split(",")]
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL","20"))
CONF_THRESH = float(os.getenv("CONF_THRESH","0.75"))
MIN_STRATEGIES = int(os.getenv("MIN_STRATEGIES","3"))
MIN_TIMEFRAMES = int(os.getenv("MIN_TIMEFRAMES","2"))
RISK_PCT = float(os.getenv("RISK_PCT","0.01"))
LEVERAGE = int(os.getenv("LEVERAGE","5"))

STRATEGY_MODULES = [
    "strategies.fibonacci_vortex",
    "strategies.quantum_entanglement",
    "strategies.darkpool_institutional",
    "strategies.gann_square",
    "strategies.elliott_neural",
    "strategies.cosmic_movement",
    "strategies.exclusive"
]

db = DB()
logger = SummaryLogger(path='trade_attempts.csv')
exchange = ExchangeClient(provider=os.getenv('EXCHANGE','binance'),
                          api_key=os.getenv('API_KEY'),
                          api_secret=os.getenv('API_SECRET'),
                          demo=DEMO_MODE)

async def scan_symbol(symbol):
    all_signals=[]
    for tf in TIMEFRAMES:
        try:
            df = exchange.fetch_ohlcv_df(symbol, timeframe=tf, limit=500)
        except Exception as e:
            log.exception('fetch failed')
            continue
        for m in STRATEGY_MODULES:
            try:
                mod = importlib.import_module(m)
                res = mod.score(df, tf, symbol)
                if res and res.get('score',0)>0:
                    all_signals.append(res)
            except Exception:
                log.exception(f'strategy {m} error')
    return all_signals

async def try_execute(agg, symbol):
    score=agg['score']; side=agg['side']
    if side=='none' or score < CONF_THRESH: return
    equity = exchange.get_balance()
    df = exchange.fetch_ohlcv_df(symbol, timeframe=TIMEFRAMES[0], limit=10)
    entry=float(df['close'].iloc[-1])
    stop = entry*0.98 if side=='buy' else entry*1.02
    qty, notional = position_size_by_risk(equity, RISK_PCT, entry, stop)
    await exchange.set_leverage(symbol, LEVERAGE)
    res = await exchange.create_order(symbol, side, qty, price=None, params={})
    db.log_trade({'symbol':symbol,'side':side,'score':score,'qty':qty,'entry':entry,'stop':stop,'res':res})
    await broadcast(f"✅ {side.upper()} {symbol} — confidence {score*100:.1f}%\nentry={entry:.6f} qty={qty:.6f} stop={stop:.6f}")

async def main_loop():
    await broadcast(f"🤖 Bot started (demo={DEMO_MODE})")
    while True:
        for symbol in SYMBOLS:
            signals = await scan_symbol(symbol)
            agg = aggregate_signals(signals, min_strategies=MIN_STRATEGIES, min_timeframes=MIN_TIMEFRAMES)
            await broadcast(f"🔎 {symbol} confluence: score={agg['score']:.3f} side={agg['side']} strategies={agg['num_strategies']} tfs={len(agg['timeframes'])}")
            if agg['score'] >= CONF_THRESH and agg['side'] in ('buy','sell'):
                await try_execute(agg, symbol)
        await asyncio.sleep(POLL_INTERVAL)

if __name__=='__main__':
    asyncio.run(main_loop())
