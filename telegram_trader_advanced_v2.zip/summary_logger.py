import csv, json, os, threading, time
class SummaryLogger:
    def __init__(self, path='trade_attempts.csv'):
        self.path = path
        self.lock = threading.Lock()
        if not os.path.exists(self.path):
            with open(self.path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['ts','symbol','side','confidence','executed','reason','entry','stop','take','qty','breakdown_json'])
    def log_attempt(self, d: dict):
        with self.lock:
            iso = ''
            try:
                iso = __import__('datetime').datetime.utcfromtimestamp(d.get('ts', time.time())).isoformat()
            except Exception:
                iso = ''
            row = [
                d.get('ts', time.time()),
                d.get('symbol',''),
                d.get('side',''),
                float(d.get('confidence',0.0)),
                bool(d.get('executed', False)),
                d.get('reason',''),
                d.get('entry',''),
                d.get('stop',''),
                d.get('take',''),
                d.get('qty',''),
                json.dumps(d.get('breakdown',''))
            ]
            with open(self.path, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)
            json_path = os.path.splitext(self.path)[0] + '.jsonl'
            with open(json_path, 'a') as jf:
                jf.write(json.dumps(d, default=str) + '\n')
